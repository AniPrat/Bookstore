package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;
import static org.hamcrest.MatcherAssert.assertThat;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.UriBuilder;

import org.hamcrest.Matchers;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.business.Book;

public class MockBookDaoTest {

	private List<Book> booksWithoutCovers;
	private List<Book> booksWithCovers;
	
	private BookDao dao;

	@BeforeEach
	void setUp() {
		MockBookDao.resetBooks();
		
		booksWithoutCovers = new ArrayList<>();
		booksWithoutCovers.add(new Book("Design Patterns", "Gamma, Helm, Johnson, Vlissides", "", 4));
		booksWithoutCovers.add(new Book("UML Distilled", "Martin Fowler", "", 3));
		booksWithoutCovers.add(new Book("Clean Code", "Robert Martin", "", 2));		
		booksWithoutCovers.add(new Book("Cryptonomicon", "Neal Stephenson", "", 1));		
		
		booksWithCovers = new ArrayList<>();
		booksWithCovers.add(new Book("Design Patterns", "Gamma, Helm, Johnson, Vlissides", "http://localhost/covers/9780201633610.jpg", 4));
		booksWithCovers.add(new Book("UML Distilled", "Martin Fowler", "http://localhost/covers/umldist.jpg", 3));
		booksWithCovers.add(new Book("Clean Code", "Robert Martin", "http://localhost/covers/cleancode.jpg", 2));		
		booksWithCovers.add(new Book("Cryptonomicon", "Neal Stephenson", "", 1));
		
		dao = new MockBookDao();
	}

	@Test
	public void testGetAllBooks() {
		List<Book> actual = dao.queryBooksByTitle("");
		assertEquals(4, actual.size());
		assertEquals(booksWithoutCovers.get(0), actual.get(0));
	}

	@Test
	public void testGetBooksByTitle() {
		List<Book> actual = dao.queryBooksByTitle("C");
		assertEquals(2, actual.size());
		assertThat(actual, Matchers.containsInAnyOrder(booksWithoutCovers.get(2), booksWithoutCovers.get(3)));
	}
	
	@Test
	public void testGetNoBooksByTitle() {
		List<Book> actual = dao.queryBooksByTitle("X");
		assertEquals(0, actual.size());
	}
	
	@Test
	public void testGetBooksByTitleWithCover() {
		UriBuilder ub = UriBuilder.fromPath("http://localhost/");
		List<Book> actual = dao.queryBooksByTitle("C", ub);
		assertEquals(2, actual.size());
		assertThat(actual, Matchers.containsInAnyOrder(booksWithCovers.get(2), booksWithCovers.get(3)));
	}	
	
	@Test
	public void testGetNoBooksByTitleWithCover() {
		UriBuilder ub = UriBuilder.fromPath("http://localhost/");
		List<Book> actual = dao.queryBooksByTitle("X", ub);
		assertEquals(0, actual.size());
	}
	
	@Test
	public void testAddBook() {
		Book expected = new Book("The Left Hand of Darkness", "Ursula K Le Guin", "", 0);
		dao.addBook(expected);
		expected.setBookId(5);
		List<Book> actual = dao.queryBooksByTitle("");
		assertEquals(5, actual.size());
		assertTrue(actual.contains(expected));
	}
}
