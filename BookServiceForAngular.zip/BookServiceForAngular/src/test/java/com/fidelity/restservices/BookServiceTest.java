package com.fidelity.restservices;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.PathSegment;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.business.Book;
import com.fidelity.integration.MockBookDao;

class BookServiceTest {
	private UriInfo uri;
	private ServletConfig sc;
	private BookService service;

	private List<Book> booksWithoutCovers;
	private List<Book> booksWithCovers;

	@BeforeEach
	void setUp() {
		MockBookDao.resetBooks();
		service = new BookService();

		uri = getMockUriInfo("/", 8080);
		service.setUri(uri);

		sc = getMockServletConfig("/");
		service.setSc(sc);

		booksWithoutCovers = new ArrayList<>();
		booksWithoutCovers.add(new Book("Design Patterns", "Gamma, Helm, Johnson, Vlissides", "", 4));
		booksWithoutCovers.add(new Book("UML Distilled", "Martin Fowler", "", 3));
		booksWithoutCovers.add(new Book("Clean Code", "Robert Martin", "", 2));		
		booksWithoutCovers.add(new Book("Cryptonomicon", "Neal Stephenson", "", 1));		

		booksWithCovers = new ArrayList<>();
		booksWithCovers.add(new Book("Design Patterns", "Gamma, Helm, Johnson, Vlissides", "http://localhost:8088/covers/9780201633610.jpg", 4));
		booksWithCovers.add(new Book("UML Distilled", "Martin Fowler", "http://localhost:8088/covers/umldist.jpg", 3));
		booksWithCovers.add(new Book("Clean Code", "Robert Martin", "http://localhost:8088/covers/cleancode.jpg", 2));		
		booksWithCovers.add(new Book("Cryptonomicon", "Neal Stephenson", "", 1));
	}

	@Test
	void testGetAllBooks() {
		List<Book> actual = service.queryBooks("");
		assertEquals(4, actual.size());
		assertEquals(booksWithoutCovers.get(0), actual.get(0));
	}

	@Test
	void testGetBooksC() {
		List<Book> actual = service.queryBooks("C");
		assertEquals(2, actual.size());
		assertThat(actual, Matchers.containsInAnyOrder(booksWithoutCovers.get(2), booksWithoutCovers.get(3)));
	}
	
	@Test
	public void testGetNoBooksByTitle() {
		List<Book> actual = service.queryBooks("X");
		assertEquals(0, actual.size());
	}
	
	@Test
	public void testGetBooksWithCoverC() {
		uri = getMockUriInfo("http://localhost/", 8088);
		service.setUri(uri);
		List<Book> actual = service.queryBooks("C");
		assertEquals(2, actual.size());
		assertThat(actual, Matchers.containsInAnyOrder(booksWithCovers.get(2), booksWithCovers.get(3)));
	}	
	
	@Test
	public void testGetNoBooksWithCover() {
		uri = getMockUriInfo("http://localhost/", 8088);
		service.setUri(uri);
		List<Book> actual = service.queryBooks("X");
		assertEquals(0, actual.size());
	}

	@Test
	public void testAddBook() {
		Book expected = new Book("The Left Hand of Darkness", "Ursula K Le Guin", "", 0);
		service.addBook(expected);
		expected.setBookId(5);
		List<Book> actual = service.queryBooks("");
		assertEquals(5, actual.size());
		assertTrue(actual.contains(expected));
	}
	private UriInfo getMockUriInfo(String baseUrl, int port) {
		UriInfo uri = new UriInfo() {

			@Override
			public UriBuilder getBaseUriBuilder() {
				return UriBuilder.fromUri(baseUrl).port(port);
			}
			
			@Override
			public URI getRequestUri() {
				return UriBuilder.fromUri(baseUrl).port(port).build();
			}
			
			// All other methods are unimplemented
			@Override
			public URI getAbsolutePath() {
				throw new UnsupportedOperationException();
			}

			@Override
			public UriBuilder getAbsolutePathBuilder() {
				throw new UnsupportedOperationException();
			}

			@Override
			public URI getBaseUri() {
				throw new UnsupportedOperationException();
			}

			@Override
			public List<Object> getMatchedResources() {
				throw new UnsupportedOperationException();
			}

			@Override
			public List<String> getMatchedURIs() {
				throw new UnsupportedOperationException();
			}

			@Override
			public List<String> getMatchedURIs(boolean arg0) {
				throw new UnsupportedOperationException();
			}

			@Override
			public String getPath() {
				throw new UnsupportedOperationException();
			}

			@Override
			public String getPath(boolean arg0) {
				throw new UnsupportedOperationException();
			}

			@Override
			public MultivaluedMap<String, String> getPathParameters() {
				throw new UnsupportedOperationException();
			}

			@Override
			public MultivaluedMap<String, String> getPathParameters(boolean arg0) {
				throw new UnsupportedOperationException();
			}

			@Override
			public List<PathSegment> getPathSegments() {
				throw new UnsupportedOperationException();
			}

			@Override
			public List<PathSegment> getPathSegments(boolean arg0) {
				throw new UnsupportedOperationException();
			}

			@Override
			public MultivaluedMap<String, String> getQueryParameters() {
				throw new UnsupportedOperationException();
			}

			@Override
			public MultivaluedMap<String, String> getQueryParameters(boolean arg0) {
				throw new UnsupportedOperationException();
			}

			@Override
			public UriBuilder getRequestUriBuilder() {
				throw new UnsupportedOperationException();
			}

			@Override
			public URI relativize(URI arg0) {
				throw new UnsupportedOperationException();
			}

			@Override
			public URI resolve(URI arg0) {
				throw new UnsupportedOperationException();
			}

		};
		return uri;
	}

	private ServletConfig getMockServletConfig(String contextPath) {
		ServletConfig sc = new ServletConfig() {

			@Override
			public String getInitParameter(String arg0) {
				throw new UnsupportedOperationException();
			}

			@Override
			public Enumeration<String> getInitParameterNames() {
				throw new UnsupportedOperationException();
			}

			@Override
			public ServletContext getServletContext() {
				ServletContext sctx = new ServletContext() {

					@Override
					public Object getAttribute(String arg0) {
						throw new UnsupportedOperationException();
					}

					@Override
					public Enumeration<String> getAttributeNames() {
						throw new UnsupportedOperationException();
					}

					@Override
					public ServletContext getContext(String arg0) {
						throw new UnsupportedOperationException();
					}

					@Override
					public String getContextPath() {
						return contextPath;
					}

					@Override
					public String getInitParameter(String arg0) {
						throw new UnsupportedOperationException();
					}

					@Override
					public Enumeration<String> getInitParameterNames() {
						throw new UnsupportedOperationException();
					}

					@Override
					public int getMajorVersion() {
						throw new UnsupportedOperationException();
					}

					@Override
					public String getMimeType(String arg0) {
						throw new UnsupportedOperationException();
					}

					@Override
					public int getMinorVersion() {
						throw new UnsupportedOperationException();
					}

					@Override
					public RequestDispatcher getNamedDispatcher(String arg0) {
						throw new UnsupportedOperationException();
					}

					@Override
					public String getRealPath(String arg0) {
						throw new UnsupportedOperationException();
					}

					@Override
					public RequestDispatcher getRequestDispatcher(String arg0) {
						throw new UnsupportedOperationException();
					}

					@Override
					public URL getResource(String arg0) throws MalformedURLException {
						throw new UnsupportedOperationException();
					}

					@Override
					public InputStream getResourceAsStream(String arg0) {
						throw new UnsupportedOperationException();
					}

					@Override
					public Set<String> getResourcePaths(String arg0) {
						throw new UnsupportedOperationException();
					}

					@Override
					public String getServerInfo() {
						throw new UnsupportedOperationException();
					}

					@Override
					public Servlet getServlet(String arg0) throws ServletException {
						throw new UnsupportedOperationException();
					}

					@Override
					public String getServletContextName() {
						throw new UnsupportedOperationException();
					}

					@Override
					public Enumeration<String> getServletNames() {
						throw new UnsupportedOperationException();
					}

					@Override
					public Enumeration<Servlet> getServlets() {
						throw new UnsupportedOperationException();
					}

					@Override
					public void log(String arg0) {
						throw new UnsupportedOperationException();
					}

					@Override
					public void log(Exception arg0, String arg1) {
						throw new UnsupportedOperationException();
					}

					@Override
					public void log(String arg0, Throwable arg1) {
						throw new UnsupportedOperationException();
					}

					@Override
					public void removeAttribute(String arg0) {
						throw new UnsupportedOperationException();
					}

					@Override
					public void setAttribute(String arg0, Object arg1) {
						throw new UnsupportedOperationException();
					}
					
				};
				return sctx;
			}

			@Override
			public String getServletName() {
				throw new UnsupportedOperationException();
			}
		};
		return sc;
	}
}
