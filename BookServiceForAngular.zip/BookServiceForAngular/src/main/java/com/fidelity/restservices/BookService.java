package com.fidelity.restservices;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import com.fidelity.business.Book;
import com.fidelity.integration.BookDao;
import com.fidelity.integration.MockBookDao;

@Path("/books")
public class BookService {
	private BookDao dao;

	@Context
	UriInfo uri;

	@Context
	ServletConfig sc;
	
	public BookService() {
		dao = new MockBookDao();
	}

	public BookService(BookDao dao) {
		this.dao = dao;
	}

	void setUri(UriInfo uri) {
		this.uri = uri;
	}

	void setSc(ServletConfig sc) {
		this.sc = sc;
	}

	@GET
	@Produces("application/json")
	public List<Book> queryBooks(@QueryParam("title") @DefaultValue("") String title) {
		List<Book> books = new ArrayList<>();

		// This looks rather complicated, but what it really does is get the absolute path of the request
		// without the 'jaxrs' at the end: this is suitable for concatenating with images.
		// If performance is really important, this could be done easily working directly with strings
		UriBuilder ub = uri.getBaseUriBuilder();
		ub.replacePath(sc.getServletContext().getContextPath());
		
		// Just for our test purposes, serve pre-defined book covers only when on port 8088
		if (uri.getRequestUri().getPort() == 8088) {
			books = dao.queryBooksByTitle(title, ub);
		} else {
			books = dao.queryBooksByTitle(title);
		}

		return books;
	}

	@POST
	@Produces("application/json")
	@Consumes("application/json")
	public Book addBook(Book book) {
		return dao.addBook(book);
	}
}
