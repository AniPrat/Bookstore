package com.fidelity.integration;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.ws.rs.core.UriBuilder;


import com.fidelity.business.Book;

public class MockBookDao implements BookDao {
	private static List<Book> books;
	private static long bookId;

	static {
		resetBooks();	
	}
	
	// Expose reset method so we can use it from tests. Not ideal, but this is a consequence of using static!
	public static void resetBooks() {
		books = new ArrayList<>();
		books.add(new Book("Design Patterns", "Gamma, Helm, Johnson, Vlissides", "/covers/9780201633610.jpg", 4));
		books.add(new Book("UML Distilled", "Martin Fowler", "/covers/umldist.jpg", 3));
		books.add(new Book("Clean Code", "Robert Martin", "/covers/cleancode.jpg", 2));		
		books.add(new Book("Cryptonomicon", "Neal Stephenson", "", 1));	
		
		bookId = 4;
	}

	private boolean startsWithIgnoreCase(String str, String prefix) {
		return str.regionMatches(true, 0, prefix, 0, prefix.length());
	}

	@Override
	public List<Book> queryBooksByTitle(String title, UriBuilder baseUriBuilder) {
		return books.stream()
				.filter(book -> startsWithIgnoreCase(book.getTitle(), title))
				.map(book -> new Book(book.getTitle(), 
						book.getAuthor(), 
						// Spectacularly ugly! This is what happens when you try to use a builder in a stream!
						book.getCover().equals("") || book.getCover().startsWith("data") ? book.getCover()
								: baseUriBuilder.clone().path(book.getCover()).build().toString(), 
						book.getBookId()))
				.collect(Collectors.toList());
	}

	@Override
	public List<Book> queryBooksByTitle(String title) {
		return books.stream()
				.filter(book -> startsWithIgnoreCase(book.getTitle(), title))
				.map(book -> new Book(book.getTitle(), 
						book.getAuthor(), 
						book.getCover().startsWith("data") ? book.getCover() : "", 
						book.getBookId()))
				.collect(Collectors.toList());
	}

	@Override
	public Book addBook(Book book) {
		book.setBookId(++bookId);
		books.add(book);
		return book;
	}
}
