package com.fidelity.integration;

import java.util.List;

import javax.ws.rs.core.UriBuilder;

import com.fidelity.business.Book;

public interface BookDao {

	List<Book> queryBooksByTitle(String title);
	Book addBook(Book book);
	List<Book> queryBooksByTitle(String title, UriBuilder baseUriBuilder);
}